//Wesley Parker
//10-23-20
//Assignment 5

import java.awt.Graphics;

abstract class Sprite
{
	int x, y;
	int w, h;

	abstract void update();
	abstract void draw(Graphics g);

	boolean isTube()	{return false;}
	boolean isMario()	{return false;}
	boolean isGoomba()	{return false;}
	boolean isFireball()	{return false;}
	boolean isBrick()	{return false;}
}