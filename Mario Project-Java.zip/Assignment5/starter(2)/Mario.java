//Wesley Parker
//10-23-20
//Assignment 5

import javax.swing.JFrame;
import java.awt.Toolkit;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Mario extends Sprite
{
	int px, py;
	double vert_vel;
	int marioLocation;  //Mario's location on screen
	int marioImageNum;
	int framesInAir;
	boolean canJump;
	static BufferedImage[] mario_images;

	public Mario(int x, int y)
	{
		this.x = x;
		this.y = y;
		w = 60;
		h = 95;
		marioLocation = 100;
		framesInAir = 0;
		marioImageNum = 0;
		mario_images = new BufferedImage[5];
		if(mario_images[0] == null)
			mario_images[0] = View.loadImage("mario1.png");
		if(mario_images[1] == null)
			mario_images[1] = View.loadImage("mario2.png");
		if(mario_images[2] == null)
			mario_images[2] = View.loadImage("mario3.png");
		if(mario_images[3] == null)
			mario_images[3] = View.loadImage("mario4.png");
		if(mario_images[4] == null)
			mario_images[4] = View.loadImage("mario5.png");
	}

	@Override
	boolean isMario() {return true;}

	void jump()
	{
		vert_vel = -20;
	}
	
	void savePreviousCoordinates()
	{
		px = x;
		py = y;
	}

	void getOutOfTube(Tube t)
	{
		//in tube, but were on left
		if(x+w >= t.x && px+w <= t.x)
			x = t.x-w;
		//in tube, but were on right
		if(x <= t.x+t.w && px >= t.x+t.w)
			x = t.x+t.w;
		//in tube, but were on top
		if(y+h >= t.y && py+h <= t.y)
		{
			y = t.y-h;
			canJump = true;
			framesInAir = 0;
			vert_vel = 0;
		}
		//in tube, but were below
		if(y <= t.y+t.h && py >= t.y+t.h)
			y = t.y+t.h;
	}

	void inAir()
	{
		if(framesInAir > 5)
			canJump = false;
		framesInAir++;
		
	}

	void update()
	{
		vert_vel += 1.2;
		y += vert_vel;
		if(y > 405)
		{
			vert_vel = 0.0;
			y = 405; // snap back to the ground
			framesInAir = 0;
			canJump = true;
		}
	}

	public void marioMove()
	{
		marioImageNum++;
		if(marioImageNum > 4)
			marioImageNum = 0;
	}

	void draw(Graphics g)
	{
		g.drawImage(mario_images[marioImageNum], marioLocation, y, null);
	}
}