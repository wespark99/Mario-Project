//Wesley Parker
//10-23-20
//Assignment 5

import java.awt.Graphics;
import java.awt.image.BufferedImage;

class Fireball extends Sprite
{
	Model model;
	static BufferedImage image;
	double vert_vel;
	int horz_vel;
	int fireImage;

	public Fireball(int x, int y, Model m)
	{
		this.x = x;
		this.y = y;
		w = 47;
		h = 47;
		vert_vel = 0.0;
		horz_vel = 5;
		model = m;
		loadImage();
	}

	void loadImage()
	{
		if(image == null)
			image = View.loadImage("fireball.png");
	}

	@Override
	boolean isFireball() {return true;}

	void update()
	{
		vert_vel += 1.2;
		y += vert_vel;
		x += horz_vel;
		if(y > 500 - h)
		{
			vert_vel = -vert_vel - .5; //bounce
		}
	}

	void draw(Graphics g)
	{
		g.drawImage(image, x - model.mario.x + model.mario.marioLocation, y, null);
	}
}