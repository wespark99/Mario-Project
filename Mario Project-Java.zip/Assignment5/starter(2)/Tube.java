//Wesley Parker
//10-23-20
//Assignment 5

import javax.swing.JFrame;
import java.awt.Toolkit;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Tube extends Sprite
{
	static BufferedImage image;
	Model model;

	public Tube(int horz, int vert, Model m)
	{
		x = horz;
		y = vert;
		w = 55;
		h = 400;
		model = m;
		loadTubeImage();
	}

	public Tube(Json ob, Model m)
	{
		x = (int)ob.getLong("tube_x");
		y = (int)ob.getLong("tube_y");
		w = 55;
		h = 400;
		model = m;
		loadTubeImage();
	}

	void loadTubeImage()
	{
		if(image == null)
			image = View.loadImage("tube.png");
	}

	void update()
	{

	}

	@Override
	boolean isTube() {return true;}

	public static void main(String[] args)
	{
		
	}	

	Json tubeMarshal()
	{
		Json ob = Json.newObject();
		ob.add("tube_x", x);
		ob.add("tube_y", y);
		return ob;
	}

	public boolean clickTube(int horz, int vert)
	{
		if(((horz >= x) && (horz <= x + w)) && ((vert >= y) && (vert <= y + h)))
			return true;
		else
			return false;
	}

	void draw(Graphics g)
	{
		g.drawImage(image, x - model.mario.x + model.mario.marioLocation, y, null);
	}
}