//Wesley Parker
//10-23-20
//Assignment 5

import java.util.ArrayList;
import java.util.Iterator;

class Model
{
	int dest_x;
	int dest_y;
	ArrayList<Sprite> sprites;
	Mario mario;

	Model()
	{
		sprites = new ArrayList<Sprite>();
		mario = new Mario(100, 300);
		sprites.add(mario);
	}

	public void update()
	{
		for(int i = 0; i < sprites.size(); i++)
		{
			sprites.get(i).update();
			if(sprites.get(i).isGoomba())//checks if goomba for sake of burning
			{
				Goomba temp = (Goomba)sprites.get(i);
				if(temp.burnTime > 20)
				{
					sprites.remove(temp);
					break;
				}
			}
			if(sprites.get(i).isTube())//checks if tube
			{
				Tube t = (Tube)sprites.get(i);
				for(int j = 0; j < sprites.size(); j++)
				{
					if(sprites.get(j).isMario())//checks if mario
					{
						if(collision(sprites.get(j), t))
						{
							Mario m = (Mario)sprites.get(j);
							m.getOutOfTube(t);
						}
					}
					if(sprites.get(j).isGoomba())//checks if goomba
					{
						if(collision(sprites.get(j), t))
						{
							Goomba g = (Goomba)sprites.get(j);
							g.bounce();
						}
					}
				}
			}
			if(sprites.get(i).isFireball())
			{
				Fireball f = (Fireball)sprites.get(i);
				for(int j = 0; j < sprites.size(); j++)
				{
					if(sprites.get(j).isGoomba())//checks if goomba
					{
						Goomba g = (Goomba)sprites.get(j);
						if(!g.onFire && collision(f, sprites.get(j)))
						{
							g.burn();
							sprites.remove(f);
						}
					}
					if(f.x - mario.x > 1000)//checks distance from mario and deletes
					{
						sprites.remove(f);
						break;
					}
				}
			}
		}
	}

	void unmarshal(Json ob)
	{
		sprites = new ArrayList<Sprite>();
		sprites.add(mario);
		Json tmpList = ob.get("sprites");
		Json tubeList = tmpList.get("tubes");
		Json goombasList = tmpList.get("goombas");
		for(int i = 0; i < tubeList.size(); i++)
			sprites.add(new Tube(tubeList.get(i), this));
		for(int i = 0; i < goombasList.size(); i++)
			sprites.add(new Goomba(goombasList.get(i), this));
	}

	Json marshal()
	{
		Json ob = Json.newObject();
		Json spritesOb = Json.newObject();
		Json tmpList = Json.newList();
        	ob.add("sprites", spritesOb);
		spritesOb.add("tubes", tmpList);
        	for(int i = 0; i < sprites.size(); i++)
			if(sprites.get(i).isTube())
			{
				Tube t = (Tube)sprites.get(i);
        			tmpList.add(t.tubeMarshal());
			}
		tmpList = Json.newList();
		spritesOb.add("goombas",tmpList);
		for(int i = 0; i < sprites.size(); i++)
			if(sprites.get(i).isGoomba())
			{
				Goomba g = (Goomba)sprites.get(i);
        			tmpList.add(g.goombaMarshal());
			}
        	return ob;
	}

	boolean collision(Sprite a, Sprite b)
	{
		if(a.x + a.w < b.x)
			return false;
		if(a.x > b.x + b.w)
			return false;
		if(a.y + a.h < b.y)
			return false;
		if(a.y > b.y + b.h)
			return false;
		return true;
	}

	public void editTube(int x, int y)
	{
		this.dest_x = x;
		this.dest_y = y;
		boolean clicked = false;
		Iterator<Sprite> spriteIterator = sprites.iterator();
		while(spriteIterator.hasNext())
		{
			Sprite tmp = spriteIterator.next();
			if(tmp.isTube())
			{
				Tube current = (Tube)tmp;
				if(current.clickTube(x, y))
				{
					sprites.remove(current);
					clicked = true;
					break;
				}
			}
		}
		if(clicked == false)
		{
			Tube t = new Tube(x, y, this);
			sprites.add(t);
		}
	}

	public void editGoomba(int x, int y)
	{
		this.dest_x = x;
		this.dest_y = y;
		boolean clicked = false;
		Iterator<Sprite> spriteIterator = sprites.iterator();
		while(spriteIterator.hasNext())
		{
			Sprite tmp = spriteIterator.next();
			if(tmp.isGoomba())
			{
				Goomba current = (Goomba)tmp;
				if(current.clickGoomba(x, y))
				{
					sprites.remove(current);
					clicked = true;
					break;
				}
			}
		}
		if(clicked == false)
		{
			Goomba g = new Goomba(x, y, this);
			sprites.add(g);
		}
	}

	public void spawnFireball(int x, int y)
	{
		Fireball f = new Fireball(x, y, this);
		sprites.add(f);
	}
}