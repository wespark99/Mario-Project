//Wesley Parker
//10-23-20
//Assignment 5

import java.awt.Graphics;
import java.awt.image.BufferedImage;

class Goomba extends Sprite
{
	Model model;
	static BufferedImage[] goomba_images;
	boolean onFire;
	double vert_vel;
	int horz_vel;
	int burnTime;
	int goombaImage;

	public Goomba(int x, int y, Model m)
	{
		this.x = x;
		this.y = y;
		w = 45;
		h = 54;
		vert_vel = 0.0;
		horz_vel = -5;
		burnTime = 0;
		goombaImage = 0;
		onFire = false;
		model = m;
		goomba_images = new BufferedImage[2];
		if(goomba_images[0] == null)
			goomba_images[0] = View.loadImage("goomba.png");
		if(goomba_images[1] == null)
			goomba_images[1] = View.loadImage("goomba_fire.png");
	}

	public Goomba(Json ob, Model m)
	{
		x = (int)ob.getLong("goomba_x");
		y = (int)ob.getLong("goomba_y");
		w = 45;
		h = 54;
		vert_vel = 0.0;
		horz_vel = -5;
		goombaImage = 0;
		onFire = false;
		model = m;
		goomba_images = new BufferedImage[2];
		if(goomba_images[0] == null)
			goomba_images[0] = View.loadImage("goomba.png");
		if(goomba_images[1] == null)
			goomba_images[1] = View.loadImage("goomba_fire.png");
	}

	Json goombaMarshal()
	{
		Json ob = Json.newObject();
		ob.add("goomba_x", x);
		ob.add("goomba_y", y);
		return ob;
	}

	public boolean clickGoomba(int horz, int vert)
	{
		if(!onFire && ((horz >= x) && (horz <= x + w)) && ((vert >= y) && (vert <= y + h)))
			return true;
		else
			return false;
	}

	void update()
	{
		if(!onFire)//onFire cancels all motion
		{
			vert_vel += 1.2;
			y += vert_vel;
			x += horz_vel;
			if(y > 500 - h)
			{
				vert_vel = 0.0;
				y = 500 - h; // snap back to the ground
			}
		}
		else//increase how long the goomba has been burning
			burnTime++;
	}

	@Override
	boolean isGoomba() {return true;}

	void bounce()
	{
		horz_vel = -horz_vel;
	}

	void burn() //the goomba is now on fire
	{
		onFire = true;
		goombaImage++;
	}

	void draw(Graphics g)
	{
		g.drawImage(goomba_images[goombaImage], x - model.mario.x + model.mario.marioLocation, y, null);
	}
}